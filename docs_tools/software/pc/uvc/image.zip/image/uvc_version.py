#coding=utf-8

import time
import os
import array

'''
typedef union
{
	struct
	{
		unsigned int year	:8;     //  0
		unsigned int mon	:6;     //  8
		unsigned int day	:6;     //  14
		unsigned int hour	:6;     //  20
		unsigned int min	:6;     //  26
	}u;
	unsigned int dw;
} Reg_Version;
'''


def get_time_ver():
    t = time.localtime(time.time())
    ver = 0;
    if (t.tm_year > 2000):
        ver |= (t.tm_year-2000)

    ver |= t.tm_mon<<8
    ver |= t.tm_mday<<14
    ver |= t.tm_hour<<20
    ver |= t.tm_min<<26
    #print ver
    return ver


def file_to_byte_array(fname):
    arr = array.array('B')
    f = open(fname, 'rb')
    arr.fromfile(f, os.path.getsize(fname))
    f.close()
    return arr

def data_to_array_pos(arrData, pos, data):
    arrData[pos+0] = (data>>0)&0xff
    arrData[pos+1] = (data>>8)&0xff
    arrData[pos+2] = (data>>16)&0xff
    arrData[pos+3] = (data>>24)&0xff


def array_to_file(arr, fname):
    f = open(fname, 'wb')
    arr.tofile(f)
    f.close()


def write_version_to_file(file_name, ver_offset):
    arrData = file_to_byte_array(file_name)
    v = get_time_ver()
    data_to_array_pos(arrData, ver_offset, v)
    data_to_array_pos(arrData, ver_offset+4, v^0xffffffff)
    array_to_file(arrData, file_name)
    pass

if __name__ == '__main__':
    write_version_to_file('Flash.img', 0xAFFF0)