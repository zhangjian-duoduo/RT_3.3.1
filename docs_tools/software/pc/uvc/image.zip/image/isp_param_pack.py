import os
import struct

class ImageInfo:
    def __init__(self):
        self.imgc_flash = 0
        self.flashBins = []
        self.flashHeaders = []
        self.filePath = "ovos05_mipi_attr.hex"

def mycrc32(szString):
    m_pdwCrc32Table = [0 for x in range(0,256)]
    dwPolynomial = 0xEDB88320;
    dwCrc = 0
    dwFileLen = 0
    for i in range(0,256):
        dwCrc = i
        for j in [8,7,6,5,4,3,2,1]:
            if dwCrc & 1:
                dwCrc = (dwCrc >> 1) ^ dwPolynomial
            else:
                dwCrc >>= 1
        m_pdwCrc32Table[i] = dwCrc
    dwCrc32 = 0xFFFFFFFF
    for i in szString:
        b = 0
        dwFileLen = dwFileLen + 1
        if type(i) == type(1):
            b = i
        else:
            b = ord(i)
        dwCrc32 = ((dwCrc32) >> 8) ^ m_pdwCrc32Table[(b) ^ ((dwCrc32) & 0x000000FF)]
    return dwCrc32, dwFileLen


def genCRCHeader(imageInfo):
    binFile = open(imageInfo.filePath, 'rb')
    binData = binFile.read()
    binFile.close()

    if len(binData) > 24560:
        binData = binData[0:24560]
        print('isp_param.hex size larger than 4080, discard data from 4080 to 4096 !!!')
        
    crc, filelen = mycrc32(binData)
    print('crc: %x len: %d' % (crc, filelen))
    paraCRC = struct.pack('I', crc)
    paraCrcCmp =  struct.pack('I', 0xffffffff-crc)
    paralen = struct.pack('I', filelen)
    paralenCmp = struct.pack('I', 0xffffffff-filelen)

    paraheader = paraCRC + paraCrcCmp + paralen + paralenCmp
    imageInfo.flashHeaders.append(paraheader)
    imageInfo.flashBins.append(binData)

imageInfo = ImageInfo()
genCRCHeader(imageInfo)
fileout = open('param_packed.bin', 'wb')

packImage =  b''.join(imageInfo.flashHeaders) + b''.join(imageInfo.flashBins)
packImage = packImage.ljust(24576, b'\x00')

fileout.write(packImage)
fileout.close()
