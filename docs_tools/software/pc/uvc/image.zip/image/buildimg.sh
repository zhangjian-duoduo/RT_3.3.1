#./mkflashimgv4 rtt_update_uvc_fh885x.ini
./mkflashimgv4 rtt_update_uvc_fh8626v100.ini
python uvc_version.py
